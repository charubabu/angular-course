export const datafields = {
    aboutus: "We offer  Tech services. We have been in the service for past 12 years. The Services that we offer are",
    servicelist: ["App Services","Testing Services", "Could Services"],
    appservices: "We offer app services on varied technologies like Angular ,React , IOS and Android. Most of applciations uses Java Platform",
    testservices: "We are poineers of Testing Services. We have a framework to carry out the testing services that eases the production quality",
    cloudservices: " We offer application hosting, database services, email services, Api Gateways, Servers as our cloud offerings"
}